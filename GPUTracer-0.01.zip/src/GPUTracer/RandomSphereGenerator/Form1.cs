﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace RandomSphereGenerator
{
    public partial class Form1 : Form
    {
        private Random _rand = new Random();

        public Form1()
        {
            InitializeComponent();

            var b = new StringBuilder();
            for (int i = 0; i < 400; i++)
            {
                b.AppendLine(GenerateSphere());
            }
            textBox1.Text = b.ToString();
        }

        private string GenerateSphere()
        {
            double x = GetRandCoordinate();
            //double y = GetRandCoordinate();
            double z = GetRandCoordinate();
            return string.Format(CultureInfo.InvariantCulture, "<sphere radius=\"0.25\"><position S0=\"{0}\" S1 =\"{1}\" S2=\"{2}\"/></sphere>", x, 0.5, z);
        }

        private double GetRandCoordinate()
        {
            return (_rand.NextDouble() - 0.5)*50;
        }
    }
}
