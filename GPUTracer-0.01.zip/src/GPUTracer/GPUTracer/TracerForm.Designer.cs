﻿namespace GPUTracer
{
    partial class TracerForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.comboBoxDeviceSelector = new System.Windows.Forms.ComboBox();
            this.DrawPanel = new GPUTracer.DrawPanel();
            this.SuspendLayout();
            // 
            // comboBoxDeviceSelector
            // 
            this.comboBoxDeviceSelector.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.comboBoxDeviceSelector.FormattingEnabled = true;
            this.comboBoxDeviceSelector.Location = new System.Drawing.Point(12, 12);
            this.comboBoxDeviceSelector.Name = "comboBoxDeviceSelector";
            this.comboBoxDeviceSelector.Size = new System.Drawing.Size(507, 21);
            this.comboBoxDeviceSelector.TabIndex = 0;
            this.comboBoxDeviceSelector.Visible = false;
            // 
            // DrawPanel
            // 
            this.DrawPanel.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.DrawPanel.Location = new System.Drawing.Point(12, 12);
            this.DrawPanel.Name = "DrawPanel";
            this.DrawPanel.Size = new System.Drawing.Size(507, 514);
            this.DrawPanel.TabIndex = 1;
            this.DrawPanel.Paint += new System.Windows.Forms.PaintEventHandler(this.DrawPanel_Paint);
            // 
            // TracerForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(528, 534);
            this.Controls.Add(this.DrawPanel);
            this.Controls.Add(this.comboBoxDeviceSelector);
            this.KeyPreview = true;
            this.Name = "TracerForm";
            this.Text = "GPUTracer";
            this.Load += new System.EventHandler(this.TracerForm_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ComboBox comboBoxDeviceSelector;
        private DrawPanel DrawPanel;
    }
}