﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using OpenCLNet;

namespace GPUTracer
{
    public class Light
    {
        private Float4 _position;
        private Float4 _color;

        public Float4 Position
        {
            get { return _position; }
        }

        public Float4 Color
        {
            get { return _color; }
        }

        public Light(Float4 position, Float4 color)
        {
            _position = position;
            _color = color;
        }

        public byte[] ToBinary()
        {
            var result = new byte[2*16];
            int c = 0;
            Helper.Float4ToByteArray(result, _position, ref c);
            Helper.Float4ToByteArray(result, _color, ref c);
            return result;
        }
    }
}
