﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GPUTracer
{
    [Serializable]
    public class KDTreeNode : KDTreeElement
    {
        public KDTreeElement RightChild { get; set; }
        public KDTreeElement LeftChild { get; set; }

        public Axis SplitAxis { get; private set; }
        public float SplitPosition { get; private set; }

        public KDTreeNode(Axis splitAxis, float splitPosition)
        {
            SplitAxis = splitAxis;
            SplitPosition = splitPosition;
        }

        public override string ToString()
        {
            return string.Format("Node:\nBoundingBox:\n{0}\nNum: {1}\n\nLeftChild:\n{2}\n\nRightChild:\n{3}\n", BBox, NumObjects, 
                LeftChild.ToString().Replace("\n", "\n\t"), RightChild.ToString().Replace("\n", "\n\t"));
        }
    }
}
