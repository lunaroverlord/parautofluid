﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using OpenCLNet;

namespace GPUTracer
{
    [Serializable]
    public class Sphere : Object
    {
        private float _radius;
        private Float4 _position;

        public Sphere(Float4 position, float radius, SurfaceType surface = SurfaceType.Shiny)
        {
            _surface = surface;
            _position = position;
            _radius = radius;
        }

        public float Radius
        {
            get { return _radius; }
        }

        public Float4 Position
        {
            get { return _position; }
        }

        public override byte[] ToBinary()
        {
            var result = new byte[64];
            int c = 0;

            Helper.Float4ToByteArray(result, _position, ref c);   //position
            Buffer.BlockCopy(BitConverter.GetBytes(_radius), 0, result, c, 4);     //radius
            c += 4 * 4 * 2;
            result[c] = 0;                  //type
            result[c+1] = (byte)Surface;      //surface

            return result;
        }

        public override string ToString()
        {
            return string.Format("Sphere - Position: ({0}, {1}, {2}) - Radius: {3}", Position.S0, Position.S1, Position.S2, Radius);
        }

        public override BoundingBox? GetBoundingBox()
        {
            var min = _position.Sub(new Float4(_radius, _radius, _radius, 0));
            var max = _position.Add(new Float4(_radius, _radius, _radius, 0));
            return new BoundingBox(min, max);
        }
    }
}
