﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using OpenCLNet;

namespace GPUTracer
{
    [Serializable]
    public abstract class Object
    {
        public enum SurfaceType
        {
            Checkerboard = 0, 
            Shiny = 1,
            Transparent = 2,
            Sky = 3,
            Wood = 4,
            TransparentAndShiny = 5
        };

        protected SurfaceType _surface;

        public SurfaceType Surface
        {
            get { return _surface; }
        }

        public abstract byte[] ToBinary();

        public abstract BoundingBox? GetBoundingBox();
    }
}
