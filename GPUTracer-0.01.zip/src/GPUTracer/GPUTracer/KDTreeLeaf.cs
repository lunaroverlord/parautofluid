﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GPUTracer
{
    [Serializable]
    public class KDTreeLeaf : KDTreeElement
    {
        protected List<Object> _containedObjects = new List<Object>();

        public List<Object> ContainedObjects
        {
            get
            {
                return _containedObjects;
            }
        }

        public void AddObject(Object o)
        {
            _containedObjects.Add(o);
        }

        public KDTreeLeaf(IEnumerable<Object> objects, BoundingBox bbox)
        {
            _containedObjects.AddRange(objects);
            NumObjects = objects.Count();
            BBox = bbox;
        }

        public override string ToString()
        {
            string ob = "";
            foreach (var o in _containedObjects)
            {
                ob += o.ToString() + "\n";
            }
            return string.Format("Leaf:\nBoundingBox:\n{0}\nNum: {1}\nObjects:\n{2}\n", BBox, NumObjects, ob);
        }
    }
}
