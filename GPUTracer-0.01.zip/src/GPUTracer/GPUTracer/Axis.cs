﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GPUTracer
{
    public enum Axis
    {
        XAxis = 0,
        YAxis = 1,
        ZAxis = 2
    }
}
