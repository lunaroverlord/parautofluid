﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using OpenCLNet;

namespace GPUTracer
{
    [Serializable]
    public struct BoundingBox
    {
        public Float4 Min { get; set; }
        public Float4 Max { get; set; }

        public BoundingBox(Float4 min, Float4 max) : this()
        {
            Min = min;
            Max = max;
        }

        public override string ToString()
        {
            return string.Format("Min: ({0}, {1}, {2})\nMax: ({3}, {4}, {5})\n", Min.S0, Min.S1, Min.S2, Max.S0, Max.S1, Max.S2);
        }
    }
}
