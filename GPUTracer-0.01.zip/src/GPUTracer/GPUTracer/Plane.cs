﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using OpenCLNet;

namespace GPUTracer
{
    [Serializable]
    public class Plane : GPUTracer.Object
    {
        private Float4 _normal;
        private float _offset;

        public float Offset
        {
            get { return _offset; }
        }

        public Float4 Normal
        {
            get { return _normal; }
        }

        public Plane(Float4 normal, float offset, SurfaceType surface = SurfaceType.Checkerboard)
        {
            _surface = surface;
            _normal = normal;
            _offset = offset;
        }

        public override byte[] ToBinary()
        {
            var result = new byte[64];
            int c = 0;

            Helper.Float4ToByteArray(result, _normal, ref c);   //normal
            Buffer.BlockCopy(BitConverter.GetBytes(_offset), 0, result, c, 4);     //offset
            c += 4 * 4 * 2;
            result[c] = 1;                  //type
            c++;
            result[c] = (byte)Surface;      //surface

            return result;
        }

        public override BoundingBox? GetBoundingBox()
        {
            return null;
        }

        public override string ToString()
        {
            return string.Format("Plane - Offset: {0} - Normal: ({1}, {2}, {3})", Offset, Normal.S0, Normal.S1, Normal.S2);
        }
    }
}
