﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GPUTracer
{
    [Serializable]
    public abstract class KDTreeElement
    {
        public int NumObjects { get; set; }
        public BoundingBox BBox { get; set; }
    }
}
