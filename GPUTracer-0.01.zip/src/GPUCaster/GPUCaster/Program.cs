﻿using System;
using System.Windows.Forms;

namespace GPUCaster
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            var casterForm = new CasterForm();
            Application.Idle += delegate { casterForm.Idle(); };
            Application.Run(casterForm);
        }
    }
}
