﻿namespace GPUCaster
{
    partial class CasterForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.comboBoxDeviceSelector = new System.Windows.Forms.ComboBox();
            this.DrawPanel = new GPUCaster.DrawPanel();
            this.Settings = new System.Windows.Forms.GroupBox();
            this.LoadStentVolumeButton = new System.Windows.Forms.Button();
            this.colorMax = new System.Windows.Forms.TrackBar();
            this.colorMin = new System.Windows.Forms.TrackBar();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.MinBoxX = new System.Windows.Forms.TrackBar();
            this.MaxBoxZ = new System.Windows.Forms.TrackBar();
            this.MaxBoxX = new System.Windows.Forms.TrackBar();
            this.MinBoxZ = new System.Windows.Forms.TrackBar();
            this.MinBoxY = new System.Windows.Forms.TrackBar();
            this.MaxBoxY = new System.Windows.Forms.TrackBar();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.CentralDifferenceOperatorRadioButton = new System.Windows.Forms.RadioButton();
            this.ZuckerHummelOperatorRadioButton = new System.Windows.Forms.RadioButton();
            this.Sobel3DOperatorRadioButton = new System.Windows.Forms.RadioButton();
            this.LoadBrainVolumeButton = new System.Windows.Forms.Button();
            this.LoadHeadVolumeButton = new System.Windows.Forms.Button();
            this.LoadBunnyButton = new System.Windows.Forms.Button();
            this.Resolution4RadioButton = new System.Windows.Forms.RadioButton();
            this.Resolution3RadioButton = new System.Windows.Forms.RadioButton();
            this.Resolution2RadioButton = new System.Windows.Forms.RadioButton();
            this.Resolution1RadioButton = new System.Windows.Forms.RadioButton();
            this.BoundingBoxMaxLabel = new System.Windows.Forms.Label();
            this.BoundingBoxMinLabel = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.LightVectorLabel = new System.Windows.Forms.Label();
            this.LightZ = new System.Windows.Forms.TrackBar();
            this.LightY = new System.Windows.Forms.TrackBar();
            this.LightX = new System.Windows.Forms.TrackBar();
            this.CutCheckBox = new System.Windows.Forms.CheckBox();
            this.DrawPanel.SuspendLayout();
            this.Settings.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.colorMax)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.colorMin)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.MinBoxX)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.MaxBoxZ)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.MaxBoxX)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.MinBoxZ)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.MinBoxY)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.MaxBoxY)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.LightZ)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LightY)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LightX)).BeginInit();
            this.SuspendLayout();
            // 
            // comboBoxDeviceSelector
            // 
            this.comboBoxDeviceSelector.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.comboBoxDeviceSelector.FormattingEnabled = true;
            this.comboBoxDeviceSelector.Location = new System.Drawing.Point(12, 12);
            this.comboBoxDeviceSelector.Name = "comboBoxDeviceSelector";
            this.comboBoxDeviceSelector.Size = new System.Drawing.Size(633, 21);
            this.comboBoxDeviceSelector.TabIndex = 0;
            this.comboBoxDeviceSelector.Visible = false;
            // 
            // DrawPanel
            // 
            this.DrawPanel.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.DrawPanel.AutoSize = true;
            this.DrawPanel.Controls.Add(this.Settings);
            this.DrawPanel.Location = new System.Drawing.Point(-3, -1);
            this.DrawPanel.Name = "DrawPanel";
            this.DrawPanel.Size = new System.Drawing.Size(658, 553);
            this.DrawPanel.TabIndex = 1;
            this.DrawPanel.Click += new System.EventHandler(this.DrawPanel_Click);
            this.DrawPanel.Paint += new System.Windows.Forms.PaintEventHandler(this.DrawPanel_Paint);
            this.DrawPanel.MouseMove += new System.Windows.Forms.MouseEventHandler(this.DrawPanel_MouseMove);
            this.DrawPanel.MouseWheel += new System.Windows.Forms.MouseEventHandler(this.DrawPanel_MouseWheel);
            // 
            // Settings
            // 
            this.Settings.Controls.Add(this.CutCheckBox);
            this.Settings.Controls.Add(this.LoadStentVolumeButton);
            this.Settings.Controls.Add(this.colorMax);
            this.Settings.Controls.Add(this.colorMin);
            this.Settings.Controls.Add(this.groupBox2);
            this.Settings.Controls.Add(this.groupBox1);
            this.Settings.Controls.Add(this.LoadBrainVolumeButton);
            this.Settings.Controls.Add(this.LoadHeadVolumeButton);
            this.Settings.Controls.Add(this.LoadBunnyButton);
            this.Settings.Controls.Add(this.Resolution4RadioButton);
            this.Settings.Controls.Add(this.Resolution3RadioButton);
            this.Settings.Controls.Add(this.Resolution2RadioButton);
            this.Settings.Controls.Add(this.Resolution1RadioButton);
            this.Settings.Controls.Add(this.BoundingBoxMaxLabel);
            this.Settings.Controls.Add(this.BoundingBoxMinLabel);
            this.Settings.Controls.Add(this.label2);
            this.Settings.Controls.Add(this.label1);
            this.Settings.Controls.Add(this.LightVectorLabel);
            this.Settings.Controls.Add(this.LightZ);
            this.Settings.Controls.Add(this.LightY);
            this.Settings.Controls.Add(this.LightX);
            this.Settings.Location = new System.Drawing.Point(7, 14);
            this.Settings.Name = "Settings";
            this.Settings.Size = new System.Drawing.Size(226, 449);
            this.Settings.TabIndex = 8;
            this.Settings.TabStop = false;
            this.Settings.Text = "Settings";
            // 
            // LoadStentVolumeButton
            // 
            this.LoadStentVolumeButton.Location = new System.Drawing.Point(175, 421);
            this.LoadStentVolumeButton.Name = "LoadStentVolumeButton";
            this.LoadStentVolumeButton.Size = new System.Drawing.Size(45, 22);
            this.LoadStentVolumeButton.TabIndex = 26;
            this.LoadStentVolumeButton.Text = "Stent";
            this.LoadStentVolumeButton.UseVisualStyleBackColor = true;
            this.LoadStentVolumeButton.Click += new System.EventHandler(this.LoadStentVolumeButton_Click);
            // 
            // colorMax
            // 
            this.colorMax.LargeChange = 1;
            this.colorMax.Location = new System.Drawing.Point(113, 176);
            this.colorMax.Maximum = 4000;
            this.colorMax.Name = "colorMax";
            this.colorMax.Size = new System.Drawing.Size(104, 45);
            this.colorMax.TabIndex = 24;
            // 
            // colorMin
            // 
            this.colorMin.LargeChange = 1;
            this.colorMin.Location = new System.Drawing.Point(6, 176);
            this.colorMin.Maximum = 4000;
            this.colorMin.Name = "colorMin";
            this.colorMin.Size = new System.Drawing.Size(104, 45);
            this.colorMin.TabIndex = 6;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.MinBoxX);
            this.groupBox2.Controls.Add(this.MaxBoxZ);
            this.groupBox2.Controls.Add(this.MaxBoxX);
            this.groupBox2.Controls.Add(this.MinBoxZ);
            this.groupBox2.Controls.Add(this.MinBoxY);
            this.groupBox2.Controls.Add(this.MaxBoxY);
            this.groupBox2.Location = new System.Drawing.Point(3, 19);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(222, 151);
            this.groupBox2.TabIndex = 10;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Bounding Box";
            // 
            // MinBoxX
            // 
            this.MinBoxX.LargeChange = 1;
            this.MinBoxX.Location = new System.Drawing.Point(0, 19);
            this.MinBoxX.Maximum = 512;
            this.MinBoxX.Name = "MinBoxX";
            this.MinBoxX.Size = new System.Drawing.Size(104, 45);
            this.MinBoxX.TabIndex = 0;
            this.MinBoxX.Scroll += new System.EventHandler(this.MinBoxX_Scroll);
            // 
            // MaxBoxZ
            // 
            this.MaxBoxZ.LargeChange = 1;
            this.MaxBoxZ.Location = new System.Drawing.Point(110, 98);
            this.MaxBoxZ.Maximum = 512;
            this.MaxBoxZ.Name = "MaxBoxZ";
            this.MaxBoxZ.Size = new System.Drawing.Size(104, 45);
            this.MaxBoxZ.TabIndex = 5;
            this.MaxBoxZ.Value = 512;
            this.MaxBoxZ.Scroll += new System.EventHandler(this.MaxBoxZ_Scroll);
            // 
            // MaxBoxX
            // 
            this.MaxBoxX.LargeChange = 1;
            this.MaxBoxX.Location = new System.Drawing.Point(110, 19);
            this.MaxBoxX.Maximum = 512;
            this.MaxBoxX.Name = "MaxBoxX";
            this.MaxBoxX.Size = new System.Drawing.Size(104, 45);
            this.MaxBoxX.TabIndex = 1;
            this.MaxBoxX.Value = 512;
            this.MaxBoxX.Scroll += new System.EventHandler(this.MaxBoxX_Scroll);
            // 
            // MinBoxZ
            // 
            this.MinBoxZ.LargeChange = 1;
            this.MinBoxZ.Location = new System.Drawing.Point(0, 98);
            this.MinBoxZ.Maximum = 512;
            this.MinBoxZ.Name = "MinBoxZ";
            this.MinBoxZ.Size = new System.Drawing.Size(104, 45);
            this.MinBoxZ.TabIndex = 4;
            this.MinBoxZ.Scroll += new System.EventHandler(this.MinBoxZ_Scroll);
            // 
            // MinBoxY
            // 
            this.MinBoxY.LargeChange = 1;
            this.MinBoxY.Location = new System.Drawing.Point(0, 62);
            this.MinBoxY.Maximum = 512;
            this.MinBoxY.Name = "MinBoxY";
            this.MinBoxY.Size = new System.Drawing.Size(104, 45);
            this.MinBoxY.TabIndex = 2;
            this.MinBoxY.Scroll += new System.EventHandler(this.MinBoxY_Scroll);
            // 
            // MaxBoxY
            // 
            this.MaxBoxY.LargeChange = 1;
            this.MaxBoxY.Location = new System.Drawing.Point(110, 62);
            this.MaxBoxY.Maximum = 512;
            this.MaxBoxY.Name = "MaxBoxY";
            this.MaxBoxY.Size = new System.Drawing.Size(104, 45);
            this.MaxBoxY.TabIndex = 3;
            this.MaxBoxY.Value = 512;
            this.MaxBoxY.Scroll += new System.EventHandler(this.MaxBoxY_Scroll);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.CentralDifferenceOperatorRadioButton);
            this.groupBox1.Controls.Add(this.ZuckerHummelOperatorRadioButton);
            this.groupBox1.Controls.Add(this.Sobel3DOperatorRadioButton);
            this.groupBox1.Location = new System.Drawing.Point(13, 236);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(207, 67);
            this.groupBox1.TabIndex = 9;
            this.groupBox1.TabStop = false;
            // 
            // CentralDifferenceOperatorRadioButton
            // 
            this.CentralDifferenceOperatorRadioButton.AutoSize = true;
            this.CentralDifferenceOperatorRadioButton.Checked = true;
            this.CentralDifferenceOperatorRadioButton.Location = new System.Drawing.Point(6, 12);
            this.CentralDifferenceOperatorRadioButton.Name = "CentralDifferenceOperatorRadioButton";
            this.CentralDifferenceOperatorRadioButton.Size = new System.Drawing.Size(150, 17);
            this.CentralDifferenceOperatorRadioButton.TabIndex = 6;
            this.CentralDifferenceOperatorRadioButton.TabStop = true;
            this.CentralDifferenceOperatorRadioButton.Text = "Central difference operator";
            this.CentralDifferenceOperatorRadioButton.UseVisualStyleBackColor = true;
            this.CentralDifferenceOperatorRadioButton.CheckedChanged += new System.EventHandler(this.CentralDifferenceRadioButtonCheckedChanged);
            // 
            // ZuckerHummelOperatorRadioButton
            // 
            this.ZuckerHummelOperatorRadioButton.AutoSize = true;
            this.ZuckerHummelOperatorRadioButton.Location = new System.Drawing.Point(6, 30);
            this.ZuckerHummelOperatorRadioButton.Name = "ZuckerHummelOperatorRadioButton";
            this.ZuckerHummelOperatorRadioButton.Size = new System.Drawing.Size(142, 17);
            this.ZuckerHummelOperatorRadioButton.TabIndex = 7;
            this.ZuckerHummelOperatorRadioButton.TabStop = true;
            this.ZuckerHummelOperatorRadioButton.Text = "Zucker-Hummel operator";
            this.ZuckerHummelOperatorRadioButton.UseVisualStyleBackColor = true;
            this.ZuckerHummelOperatorRadioButton.CheckedChanged += new System.EventHandler(this.ZuckerHummelRadioButtonCheckedChanged);
            // 
            // Sobel3DOperatorRadioButton
            // 
            this.Sobel3DOperatorRadioButton.AutoSize = true;
            this.Sobel3DOperatorRadioButton.Location = new System.Drawing.Point(6, 47);
            this.Sobel3DOperatorRadioButton.Name = "Sobel3DOperatorRadioButton";
            this.Sobel3DOperatorRadioButton.Size = new System.Drawing.Size(108, 17);
            this.Sobel3DOperatorRadioButton.TabIndex = 8;
            this.Sobel3DOperatorRadioButton.TabStop = true;
            this.Sobel3DOperatorRadioButton.Text = "Sobel3D operator";
            this.Sobel3DOperatorRadioButton.UseVisualStyleBackColor = true;
            this.Sobel3DOperatorRadioButton.CheckedChanged += new System.EventHandler(this.Sobel3DRadioButtonCheckedChanged);
            // 
            // LoadBrainVolumeButton
            // 
            this.LoadBrainVolumeButton.Location = new System.Drawing.Point(175, 399);
            this.LoadBrainVolumeButton.Name = "LoadBrainVolumeButton";
            this.LoadBrainVolumeButton.Size = new System.Drawing.Size(45, 22);
            this.LoadBrainVolumeButton.TabIndex = 23;
            this.LoadBrainVolumeButton.Text = "Brain";
            this.LoadBrainVolumeButton.UseVisualStyleBackColor = true;
            this.LoadBrainVolumeButton.Click += new System.EventHandler(this.LoadBrainVolumeButton_Click);
            // 
            // LoadHeadVolumeButton
            // 
            this.LoadHeadVolumeButton.Location = new System.Drawing.Point(175, 378);
            this.LoadHeadVolumeButton.Name = "LoadHeadVolumeButton";
            this.LoadHeadVolumeButton.Size = new System.Drawing.Size(45, 22);
            this.LoadHeadVolumeButton.TabIndex = 22;
            this.LoadHeadVolumeButton.Text = "Head";
            this.LoadHeadVolumeButton.UseVisualStyleBackColor = true;
            this.LoadHeadVolumeButton.Click += new System.EventHandler(this.LoadHeadVolumeButton_Click);
            // 
            // LoadBunnyButton
            // 
            this.LoadBunnyButton.Location = new System.Drawing.Point(175, 357);
            this.LoadBunnyButton.Name = "LoadBunnyButton";
            this.LoadBunnyButton.Size = new System.Drawing.Size(45, 22);
            this.LoadBunnyButton.TabIndex = 21;
            this.LoadBunnyButton.Text = "Bunny";
            this.LoadBunnyButton.UseVisualStyleBackColor = true;
            this.LoadBunnyButton.Click += new System.EventHandler(this.LoadBunnyButton_Click);
            // 
            // Resolution4RadioButton
            // 
            this.Resolution4RadioButton.AutoSize = true;
            this.Resolution4RadioButton.Location = new System.Drawing.Point(93, 421);
            this.Resolution4RadioButton.Name = "Resolution4RadioButton";
            this.Resolution4RadioButton.Size = new System.Drawing.Size(80, 17);
            this.Resolution4RadioButton.TabIndex = 20;
            this.Resolution4RadioButton.TabStop = true;
            this.Resolution4RadioButton.Text = "1024 X 768";
            this.Resolution4RadioButton.UseVisualStyleBackColor = true;
            this.Resolution4RadioButton.CheckedChanged += new System.EventHandler(this.radioButton4_CheckedChanged);
            // 
            // Resolution3RadioButton
            // 
            this.Resolution3RadioButton.AutoSize = true;
            this.Resolution3RadioButton.Location = new System.Drawing.Point(93, 401);
            this.Resolution3RadioButton.Name = "Resolution3RadioButton";
            this.Resolution3RadioButton.Size = new System.Drawing.Size(74, 17);
            this.Resolution3RadioButton.TabIndex = 19;
            this.Resolution3RadioButton.TabStop = true;
            this.Resolution3RadioButton.Text = "800 X 600";
            this.Resolution3RadioButton.UseVisualStyleBackColor = true;
            this.Resolution3RadioButton.CheckedChanged += new System.EventHandler(this.radioButton3_CheckedChanged);
            // 
            // Resolution2RadioButton
            // 
            this.Resolution2RadioButton.AutoSize = true;
            this.Resolution2RadioButton.Checked = true;
            this.Resolution2RadioButton.Location = new System.Drawing.Point(6, 421);
            this.Resolution2RadioButton.Name = "Resolution2RadioButton";
            this.Resolution2RadioButton.Size = new System.Drawing.Size(74, 17);
            this.Resolution2RadioButton.TabIndex = 18;
            this.Resolution2RadioButton.TabStop = true;
            this.Resolution2RadioButton.Text = "640 X 480";
            this.Resolution2RadioButton.UseVisualStyleBackColor = true;
            this.Resolution2RadioButton.CheckedChanged += new System.EventHandler(this.radioButton2_CheckedChanged_1);
            // 
            // Resolution1RadioButton
            // 
            this.Resolution1RadioButton.AutoSize = true;
            this.Resolution1RadioButton.Location = new System.Drawing.Point(6, 401);
            this.Resolution1RadioButton.Name = "Resolution1RadioButton";
            this.Resolution1RadioButton.Size = new System.Drawing.Size(74, 17);
            this.Resolution1RadioButton.TabIndex = 17;
            this.Resolution1RadioButton.TabStop = true;
            this.Resolution1RadioButton.Text = "512 X 384";
            this.Resolution1RadioButton.UseVisualStyleBackColor = true;
            this.Resolution1RadioButton.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged_1);
            // 
            // BoundingBoxMaxLabel
            // 
            this.BoundingBoxMaxLabel.AutoSize = true;
            this.BoundingBoxMaxLabel.Location = new System.Drawing.Point(118, 370);
            this.BoundingBoxMaxLabel.Name = "BoundingBoxMaxLabel";
            this.BoundingBoxMaxLabel.Size = new System.Drawing.Size(37, 13);
            this.BoundingBoxMaxLabel.TabIndex = 16;
            this.BoundingBoxMaxLabel.Text = "(0,0,0)";
            // 
            // BoundingBoxMinLabel
            // 
            this.BoundingBoxMinLabel.AutoSize = true;
            this.BoundingBoxMinLabel.Location = new System.Drawing.Point(118, 357);
            this.BoundingBoxMinLabel.Name = "BoundingBoxMinLabel";
            this.BoundingBoxMinLabel.Size = new System.Drawing.Size(37, 13);
            this.BoundingBoxMinLabel.TabIndex = 15;
            this.BoundingBoxMinLabel.Text = "(0,0,0)";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(118, 343);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(73, 13);
            this.label2.TabIndex = 14;
            this.label2.Text = "BoundingBox:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(118, 309);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(64, 13);
            this.label1.TabIndex = 13;
            this.label1.Text = "LightVector:";
            // 
            // LightVectorLabel
            // 
            this.LightVectorLabel.AutoSize = true;
            this.LightVectorLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LightVectorLabel.Location = new System.Drawing.Point(118, 324);
            this.LightVectorLabel.Name = "LightVectorLabel";
            this.LightVectorLabel.Size = new System.Drawing.Size(37, 13);
            this.LightVectorLabel.TabIndex = 12;
            this.LightVectorLabel.Text = "(0,0,0)";
            // 
            // LightZ
            // 
            this.LightZ.LargeChange = 1;
            this.LightZ.Location = new System.Drawing.Point(8, 364);
            this.LightZ.Maximum = 1000;
            this.LightZ.Minimum = -1000;
            this.LightZ.Name = "LightZ";
            this.LightZ.Size = new System.Drawing.Size(104, 45);
            this.LightZ.TabIndex = 11;
            this.LightZ.Value = -254;
            this.LightZ.Scroll += new System.EventHandler(this.LightZ_Scroll);
            // 
            // LightY
            // 
            this.LightY.LargeChange = 1;
            this.LightY.Location = new System.Drawing.Point(8, 336);
            this.LightY.Maximum = 1000;
            this.LightY.Minimum = -1000;
            this.LightY.Name = "LightY";
            this.LightY.Size = new System.Drawing.Size(104, 45);
            this.LightY.TabIndex = 10;
            this.LightY.Value = -254;
            this.LightY.Scroll += new System.EventHandler(this.LightY_Scroll);
            // 
            // LightX
            // 
            this.LightX.LargeChange = 1;
            this.LightX.Location = new System.Drawing.Point(8, 309);
            this.LightX.Maximum = 1000;
            this.LightX.Minimum = -1000;
            this.LightX.Name = "LightX";
            this.LightX.Size = new System.Drawing.Size(104, 45);
            this.LightX.TabIndex = 9;
            this.LightX.Value = 256;
            this.LightX.Scroll += new System.EventHandler(this.LightX_Scroll);
            // 
            // CutCheckBox
            // 
            this.CutCheckBox.AutoSize = true;
            this.CutCheckBox.Location = new System.Drawing.Point(8, 213);
            this.CutCheckBox.Name = "CutCheckBox";
            this.CutCheckBox.Size = new System.Drawing.Size(66, 17);
            this.CutCheckBox.TabIndex = 9;
            this.CutCheckBox.Text = "Cut data";
            this.CutCheckBox.UseVisualStyleBackColor = true;
            // 
            // CasterForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(654, 550);
            this.Controls.Add(this.DrawPanel);
            this.Controls.Add(this.comboBoxDeviceSelector);
            this.Name = "CasterForm";
            this.Text = "GPUCaster";
            this.Load += new System.EventHandler(this.CasterForm_Load);
            this.DrawPanel.ResumeLayout(false);
            this.Settings.ResumeLayout(false);
            this.Settings.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.colorMax)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.colorMin)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.MinBoxX)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.MaxBoxZ)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.MaxBoxX)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.MinBoxZ)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.MinBoxY)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.MaxBoxY)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.LightZ)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LightY)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LightX)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox comboBoxDeviceSelector;
        private DrawPanel DrawPanel;
        private System.Windows.Forms.TrackBar MinBoxX;
        private System.Windows.Forms.TrackBar MaxBoxX;
        private System.Windows.Forms.TrackBar MaxBoxY;
        private System.Windows.Forms.TrackBar MinBoxY;
        private System.Windows.Forms.TrackBar MaxBoxZ;
        private System.Windows.Forms.TrackBar MinBoxZ;
        private System.Windows.Forms.RadioButton ZuckerHummelOperatorRadioButton;
        private System.Windows.Forms.RadioButton CentralDifferenceOperatorRadioButton;
        private System.Windows.Forms.RadioButton Sobel3DOperatorRadioButton;
        private System.Windows.Forms.GroupBox Settings;
        private System.Windows.Forms.TrackBar LightZ;
        private System.Windows.Forms.TrackBar LightY;
        private System.Windows.Forms.TrackBar LightX;
        private System.Windows.Forms.Label LightVectorLabel;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label BoundingBoxMaxLabel;
        private System.Windows.Forms.Label BoundingBoxMinLabel;
        private System.Windows.Forms.RadioButton Resolution2RadioButton;
        private System.Windows.Forms.RadioButton Resolution1RadioButton;
        private System.Windows.Forms.RadioButton Resolution4RadioButton;
        private System.Windows.Forms.RadioButton Resolution3RadioButton;
        private System.Windows.Forms.Button LoadHeadVolumeButton;
        private System.Windows.Forms.Button LoadBunnyButton;
        private System.Windows.Forms.Button LoadBrainVolumeButton;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TrackBar colorMax;
        private System.Windows.Forms.TrackBar colorMin;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button LoadStentVolumeButton;
        private System.Windows.Forms.CheckBox CutCheckBox;        
    }
}