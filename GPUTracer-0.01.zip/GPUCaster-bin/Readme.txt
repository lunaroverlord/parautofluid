You have to download the models first before using this application.

http://graphics.stanford.edu/data/voldata/CThead.tar.gz
http://graphics.stanford.edu/data/voldata/bunny-ctscan.tar.gz
http://graphics.stanford.edu/data/voldata/MRbrain.tar.gz

Download them and copy them to the GPUTracer directory.